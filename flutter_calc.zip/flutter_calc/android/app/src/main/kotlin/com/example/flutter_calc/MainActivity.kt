package com.example.flutter_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
